# Advanced Architecture

## Changes from 22.04.18 Ending Codebase


### Renamed/Moved

- All prefabs now are in the `engine/prefabs` folder.
- All engine-level components are now in the `engine/components` folder.

### Removed

### Added

- A new game that demonstrates simple linear phyics, `flappy.html`

### Changed

