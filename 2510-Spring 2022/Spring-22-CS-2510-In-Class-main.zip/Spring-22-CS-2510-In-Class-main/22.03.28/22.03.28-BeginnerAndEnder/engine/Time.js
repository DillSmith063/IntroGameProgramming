class Time{
  static millisecondsBetweenFrames = 100;
  static secondsBetweenFrame = Time.millisecondsBetweenFrames/1000;
  static timePassed = 0;
}

export default Time;