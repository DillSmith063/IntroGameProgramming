class MathLine{
  constructor(p, c){
    this.p = p;
    this.c = c;
  }
}

export default MathLine