# Advanced Architecture

## Changes from 22.03.21 Ending Codebase


### Renamed

### Removed

### Added

- Scene now takes a background color parameter after its name. If no color is provided, it defaults to "black".

### Changed

- Updated Input.getMousePosition and Input.getMousePositionDelta to return an object with two values.

