# 22.02.02_MVC
Split our simple game into a game loop and separating the model, view, and controller
