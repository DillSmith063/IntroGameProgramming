class Time{
  static millisecondsBetweenFrames = 10;
  static secondsBetweenFrame = .01;
  static timePassed = 0;
}