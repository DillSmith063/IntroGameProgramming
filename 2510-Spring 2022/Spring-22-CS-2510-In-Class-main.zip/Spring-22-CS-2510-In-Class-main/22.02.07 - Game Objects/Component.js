class Component{
  constructor(parent){
    this.parent = parent;
  }
}