class Time{
  static millisecondsBetweenFrames = 100;
  static secondsBetweenFrame = .1;
  static timePassed = 0;
}

export default Time;