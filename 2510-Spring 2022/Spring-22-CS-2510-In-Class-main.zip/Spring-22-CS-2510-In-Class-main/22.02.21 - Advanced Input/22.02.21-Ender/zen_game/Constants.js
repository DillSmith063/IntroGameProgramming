class Constants{
  static max = 30;
  static startX = 100;
  static offsetX = 50;
  static maxWidth = 400;
  static startY = 400;

  static width = 10;
  static height = 50;
}

export default Constants;