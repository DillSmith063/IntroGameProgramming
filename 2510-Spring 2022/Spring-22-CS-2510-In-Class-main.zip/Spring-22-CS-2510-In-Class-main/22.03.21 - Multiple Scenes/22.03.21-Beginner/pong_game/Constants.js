class Constants{
  static wallWidth = 10;
  static wallLength = 200;
  static startX = 100;
  static startY = 100;
  static paddleWidth = 50;

}

export default Constants;