import Component from "../engine/Component.js"
import Game from "../engine/Game.js";
import Time from "../engine/Time.js"


class StartUpdateComponent extends Component {
  constructor(parent) {
    super(parent);
    
  }
  update() {
    
  }
}

export default StartUpdateComponent;