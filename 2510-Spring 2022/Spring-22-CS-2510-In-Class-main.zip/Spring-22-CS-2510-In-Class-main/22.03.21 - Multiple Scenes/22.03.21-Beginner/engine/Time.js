class Time{
  static millisecondsBetweenFrames = 10;
  static secondsBetweenFrame = Time.millisecondsBetweenFrames/1000;
  static timePassed = 0;
}

export default Time;