class Time{
  static millisecondsBetweenFrames = 1000;
  static secondsBetweenFrame = 1000/Time.secondsBetweenFrame;
  static timePassed = 0;
}

export default Time;