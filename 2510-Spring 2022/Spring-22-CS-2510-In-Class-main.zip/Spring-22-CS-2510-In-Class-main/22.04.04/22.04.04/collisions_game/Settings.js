export default {
  rectangleX : 250,
  rectangleY : 250,
  rectangleW : 75,
  rectangleH : 25,
  circleRadius: 25,
  collisionCircleRadius:25,
}