# 22.01.31---Adding-Time
Adding time to our simple game loop.
