# 22.01.26---Three-ways-to-draw
Three ways to draw geometry
