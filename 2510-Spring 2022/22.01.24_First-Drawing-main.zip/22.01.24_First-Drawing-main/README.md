# 2022.Day01
Simple html setup
